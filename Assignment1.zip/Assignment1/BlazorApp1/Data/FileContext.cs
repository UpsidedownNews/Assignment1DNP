﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Text.Json;
using Blazorapp1.Models;

namespace BlazorApp1.Data
{
    public class FileContext
    {
        public IList<Family> Families { get; private set; }
        public IList<Adult> Adults { get; private set; }

        private readonly string familiesFile = @"C:\Users\jaime\source\repos\BlazorApp1\BlazorApp1\Data\families.json";
        private readonly string adultsFile = @"C:\Users\jaime\source\repos\BlazorApp1\BlazorApp1\Data\adults.json";

        public FileContext()
        {
            Families = File.Exists(familiesFile) ? ReadData<Family>(familiesFile) : new List<Family>();
            Adults = File.Exists(adultsFile) ? ReadData<Adult>(adultsFile) : new List<Adult>();
            Console.WriteLine(Adults.Count());
            
  
        }
        
        private IList<T> ReadData<T>(string s)
        {
            using (var jsonReader = File.OpenText(s))
            {
                return JsonSerializer.Deserialize<List<T>>(jsonReader.ReadToEnd());
            }
        }

        public Task<IList<Adult>> GetAdultsAsync()
        {
            return Task.FromResult(Adults);
        }

        public IList<Adult> GetAdultList()
        {
            return Adults;
        }

        public IList<Adult> GetAdultByFirstName(string Name)
        {
            IList<Adult> TempList = new List<Adult>();

            foreach(var adultTemp in Adults)
            {
                if(adultTemp.FirstName.Equals(Name))
                {
                    TempList.Add(adultTemp);
                }
            }
            return TempList;
        }

        public Adult GetAdultById(int Id)
        {
            foreach(var adult in Adults)
            {
                if(adult.Id == Id)
                {
                    return adult;
                }
            }
            return null;
        }

        public void AddAdult(int Id, string FirstName, string LastName, string HairColor, string EyeColor, int Height, float Weight, string Sex, string ImageUrl)
        {
            Adults.Add(new Adult
            {
                Id = Id,
                FirstName = FirstName,
                LastName = LastName,
                HairColor = HairColor,
                EyeColor = EyeColor,
                Height = Height,
                Weight = Weight,
                Sex = Sex,
                ImageUrl = ImageUrl
                
            });
            SaveChanges();
        }

        public void SaveChanges()
        {
            // storing families
            string jsonFamilies = JsonSerializer.Serialize(Families, new JsonSerializerOptions
            {
                WriteIndented = true
            });
            using (StreamWriter outputFile = new StreamWriter(familiesFile, false))
            {
                outputFile.Write(jsonFamilies);
            }

            // storing persons
            string jsonAdults = JsonSerializer.Serialize(Adults, new JsonSerializerOptions
            {
                WriteIndented = true
            });
            using (StreamWriter outputFile = new StreamWriter(adultsFile, false))
            {
                outputFile.Write(jsonAdults);
            }
        }
    }
}
