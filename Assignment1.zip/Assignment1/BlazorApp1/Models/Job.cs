using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Blazorapp1.Models
{
    public class Job
    {
        public string JobTitle { get; set; }
        public int Salary { get; set; }
    }
}